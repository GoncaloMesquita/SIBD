#!/usr/bin/python3
IST_ID = 'ist194037'
host = 'db.tecnico.ulisboa.pt'
port = 5432
password = 'caput5356'
db_name = IST_ID
credentials = 'host={} port={} user={} password={} dbname={}'.format(host, port, IST_ID,password, db_name)
